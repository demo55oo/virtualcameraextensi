# DirectShow Base Classes
This library is built from directshow base classes, you can find the source code from windows sdk 7.1 samples (\multimedia\directshow\baseclasses).
[Check msdn for more detail](https://docs.microsoft.com/en-us/windows/desktop/directshow/using-the-directshow-base-classes).

## Build enviroment
- IDE : Visual studio 2017 community
- Character set: ANSI
- platform: x86,x64
