#ifndef VIRTUAL_FILTER_H
#define VIRTUAL_FILTER_H

void virtual_filter_init();

#endif